#include <ros/ros.h>
#include <ros/package.h>
#include <mover_client/grid_num.h>
#include <mover_client/grid_num_vector.h>
#include <stdlib.h>
#include <string>
#include <fstream>
#include <vector>
#include <iomanip>
#include <iostream>

mover_client::grid_num_vector grid_facts;
bool vector_received;

void grid_vectorReceived(const mover_client::grid_num_vector& grid_vector)
{
    ROS_INFO_STREAM("Recieved the following vector of grids:\n");        
    for( int i = 0; i < grid_vector.numbered_grids.size(); i++ )
    {
         ROS_INFO_STREAM("(" << grid_vector.numbered_grids[i].row <<"," 
         					 << grid_vector.numbered_grids[i].col <<"," 
         					 << grid_vector.numbered_grids[i].num <<")");

         if( i+1 != grid_vector.numbered_grids.size() )
	     	ROS_INFO_STREAM(", ");
    }
    ROS_INFO_STREAM("\n"); 

    // assigning of our received vector to a global variable for use in the main function
    grid_facts = grid_vector;

    // setting of our flag - necessary for continuation of program
    vector_received = true;	   
}

int generate_facts_file() {

	// opening a file stream for our facts file
	std::ofstream fileWrite("my_sudoku_facts.lp");

	if (!fileWrite.is_open()) {
		return 0;
	}
	else {
		// for each numbered grid in our vector, write as an ASP fact in our file
		for (int i = 0; i < grid_facts.numbered_grids.size(); i++) {
			fileWrite << "gridNum(" << grid_facts.numbered_grids[i].row << ","
									<< grid_facts.numbered_grids[i].col << ","
									<< grid_facts.numbered_grids[i].num << ")."
									<< "\n";
		}

		fileWrite.close();
		return 1;
	}
}

bool is_unsatisfiable(string results) {


	return true;
}

std::string extract_results() {

	// string to hold results
	std::string results, buffer;

	// opening of the results file
	std::ifstream fileRead("result.txt");
	if (fileRead.is_open()) {

		// extracting each line to our results
		while(getline(fileRead, buffer)) {
			results.append(buffer);
		}
	}

	return results;
}


int main(int argc, char **argv)
{
	// initializing of subscriber node
	ros::init(argc, argv, "interface_node");
	ros::NodeHandle nh;
	ros::Subscriber sub = nh.subscribe("num_grids/vector", 1000, &grid_vectorReceived);

	/* 
	listening for a vector from the num_grids/vector:
		- bool flag stops calling of callback function once received		
	*/
	vector_received = false;	
	ROS_INFO_STREAM("Listening for vectors...\n");	

	while (vector_received == false && ros::ok()) {
		ros::spinOnce();
	}

	/*
	solving of the assigned facts via clingo
		- the recieved vector is firstly encoded into ASP facts
		- our asp solver and asp program are executed via system call
	*/
	ROS_INFO_STREAM("Attempting to solve vector of grids...\n");

	if (generate_facts_file() == 0) {
		ROS_INFO_STREAM("Unable to generate facts file");
		return 0;
	}
	else {
		// executing ASP solver with our generated file
		system("./clingo my_sudoku_facts.lp my_sudoku_ASP_program.lp >> result.txt");
	}

	/*
	encoding of clingo results into grid_num_vector message type
		- push results into a string
		
		PROCESS RESULTS
		- if pattern 'UNSATISFIABLE' detected; produce error
		- else 
			ENCODE RESULTS
			- for each occurence of 'grid('
			- extract chars from string index: [('grid(' index], [+1], [+3], [+5]
			- push each of the extracted chars into a new vector as integers
			}
		}
	*/
	ROS_INFO_STREAM("Encoding results...\n");
	
	// extract results into a string
	std::string results = extract_results();
	if (results.empty()) {
		ROS_INFO_STREAM("Unable extract results");
		return 0;
	}

	// processing of results


}