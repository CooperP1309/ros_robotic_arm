#ifndef CLAUSE_OUTPUTS_H
#define CLAUSE_OUTPUTS_H

#include "sudoku.h"
#include "formulas.h"
using namespace std;

class ClauseOutput {
private:
	unordered_map<string,int> atomMap; 	// map for storing atoms (keys will literals for comparisons)
	int numAtoms = 1, numClauses = 0;	// stores the number of distinct atoms and clauses respectively

	string generateClauses();		// compiles the clauses of each formula into a single structure
	void mapAtoms(string&);		// derives each atom in our clauses string and maps them
	void outputDIMACS(string);		// outputs the string in DIMACS format via the mapped atoms
	void retrieveKey(int);			// given a value, this function retrieves the corresponding key in a map

public: 
	void outputAll();			// a central function to employ the whole class
	void recoverVariables(string);	// using the output of zchaff, this method translates each index
};						// back into their original human readable names

string ClauseOutput::generateClauses() {
	
	// structure to hold our resulting clauses
	string clauses; 
	
	// objects of our hardcoded sudoku board and formulas
	Sudoku board;
	Formulas formula;

	// compiling clauses into a single string
	clauses.append(formula.outputFMentions());
	clauses.append(formula.outputFRowToGrid());
	clauses.append(formula.outputFColToGrid());
	clauses.append(formula.outputFSBToGrid());
	clauses.append(formula.outputFOneNumGrid());
	clauses.append(board.outputSudokuGrids());
	
	clauses.erase(0,1);

	return clauses; 
}

void ClauseOutput::mapAtoms(string& clauses) {

	int atomIndex = 1;

	// convert clauses string into stream
	stringstream stream(clauses);	
	string buffer;

	// process line by line
	while (getline(stream, buffer)) {

		numClauses++;

		// extract individual atoms
		stringstream clauseStream(buffer);
		string clause;

		// ">>" ignores " " as input, thus seperating atoms
		while (clauseStream >> clause) {
			
			// processing of each atom here
			// break when we already have an atom mapped
			if (atomMap.count(clause)) {
				continue;
			}

			atomMap.insert({clause, numAtoms});
			atomIndex++;
			numAtoms++;
		}
	}
}

void ClauseOutput::outputDIMACS(string clauses) {

	// outputting problem line prior to body
	cout << "p cnf " << numAtoms-1 << " " << numClauses << "\n";

	int clauseIndex = 1;

	// convert clauses string into stream
	stringstream stream(clauses);	
	string buffer;

	// process line by line
	while (getline(stream, buffer)) {

		// indexing of every clause
		//cout << clauseIndex << " ";
		clauseIndex++;

		// extract individual atoms
		stringstream clauseStream(buffer);
		string clause;

		// ">>" ignores " " as input, thus seperating atoms
		while (clauseStream >> clause) {
			
			// assuming each atom is already mapped...
			// output the corresponding index whilst also
			// accounting for the negation of the atom
			if (clause[0] == '-') {
				cout << "-";
			}
			cout << atomMap[clause] << " ";
		}
		cout << "0" << "\n";
	}
}

void ClauseOutput::retrieveKey(int value) {

	// making sure no negative integers are passed through
	if (value < 0) {
		value = value*-1;
	}

	// used to operate with any strings we find
	string atom;

	// iterate through the map. Iteration can be
	// automatically determined via the assumption
	// that the map already exists
	for (auto it = atomMap.begin(); it != atomMap.end(); it++) {
		if (it->second == value) {
			
			atom = it->first;

			if (atom[0] == '-') {
				atom.erase(0,1);
			}
			cout << "Found " << atom << " from " << value << endl;
		}
	}
}

void ClauseOutput::outputAll() {

	// generating and compiling of clauses
	string clauses = generateClauses();

	// mapping of atoms
	mapAtoms(clauses);

	// converting and outputting via map
	outputDIMACS(clauses);
}

void ClauseOutput::recoverVariables(string zchaff_file_name) {

	// Generate the variable strings and map them
	string clauses = generateClauses();
	mapAtoms(clauses);

	// open an input stream for the zchaff results file
	ifstream readFile(zchaff_file_name);
	string buffer;

	// variables used to determine when the atoms section starts
	string startStr = "satisfiable", endStr = "Max";
	bool usingAtoms = false;

	// process line by line
	while (getline(readFile, buffer)) {

		stringstream wordStream(buffer);
		string word;

		while (wordStream >> word) {

			// only process words as atoms when between end and start strings
			if (usingAtoms == true && word != endStr) {				
				int value = stoi(word);							// <-- Actual recovery of atoms starts here
				retrieveKey(value);
			}														
			else {
				usingAtoms = false;
			}

			// indexed atoms start after the pattern "satisfiable"
			if (word == startStr){
				usingAtoms = true;
			}
		}
	}
}

#endif
