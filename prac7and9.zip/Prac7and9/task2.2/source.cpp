/*
By Cooper Peek 22093312

OUTPUT DIMACS CNF CLAUSES

  $ g++ -o clauses source.cpp
  $ ./clauses

Note: All three ".h" files must be in the same folder as
this "source.cpp" file when compiling.


RECOVER VARIABLE NAMES FROM ZCHAFF:

  $./'zchaff(1)' <file_name> >> <zchaff_output_file>
  $./clauses <zchaff_output_file>

Flow of class structure:
  
  formulas    sudoku
      |          |
      |          |
      ------------
           |
     clause_outputs
           |
      source/main     
*/

#include <iostream>
#include <string>
#include <sstream>
#include <unordered_map>
#include <fstream>
#include "clause_outputs.h"
using namespace std;

int main(int argc, char* argv[]) {
  
  ClauseOutput output;

  if (argc > 1) {
    cout << "input file detected. Recovering variables..." << "\n";
    output.recoverVariables(argv[1]);
  }
  else {
    output.outputAll();
  } 


}