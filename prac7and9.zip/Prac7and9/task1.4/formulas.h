#ifndef FORMULAS_H
#define FORMULAS_H

#include <string>
using namespace std;

class Formulas {
public:
	string outputFMentions();
	string outputFRowToGrid();
	string outputFColToGrid();
	string outputFSBToGrid();
	string outputFOneNumGrid();
};

string Formulas::outputFMentions() {

  // string to store result in
  string result;

  // Generate row clauses
  for (int i = 0; i < 9; i++) {
      for (int j = 0; j < 9; j++) {
        result.append("R_");
        result.append(to_string(i+1));
        result.append("_");
        result.append(to_string(j+1));
        result.append("\n");
      }
  }

  // Generate col clauses
  for (int i = 0; i < 9; i++) {
      for (int j = 0; j < 9; j++) {
        result.append("C_");
        result.append(to_string(i+1));
        result.append("_");
        result.append(to_string(j+1));
        result.append("\n");
      }
  }

  // Generate SB clauses
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 9; k++) {
        result.append("SB_");
        result.append(to_string(i+1));
        result.append("_");
        result.append(to_string(j+1));
        result.append("_");
        result.append(to_string(k+1));
        result.append("\n");
      }
    }
  }

  return result;
}

string Formulas::outputFRowToGrid() {

  // string to store result in
  string result;

  // Looping of each row (i) 
  for (int i = 0; i < 9; i++) {

    // nested looping of each number possible (j)
    for (int j = 0; j < 9; j++) {

      result.append("-R_");
      result.append(to_string(i+1));
      result.append("_");
      result.append(to_string(j+1));
      result.append(" ");

        // nested looping of each grid within the i-th row that could contain j
        for (int k = 0; k < 9; k++) {

        result.append("G_");
        result.append(to_string(i+1));
        result.append("_");
        result.append(to_string(k+1));
        result.append("_");
        result.append(to_string(j+1));
        result.append(" ");
        }

      result.append("\n");
    }
  }

  return result;
}

string Formulas::outputFColToGrid() {

  // string to store result in
  string result;

  // Looping of each col (i) 
  for (int i = 0; i < 9; i++) {

    // nested looping of each number possible (j)
    for (int j = 0; j < 9; j++) {
      result.append("-C_");
      result.append(to_string(i+1));
      result.append("_");
      result.append(to_string(j+1));
      result.append(" ");

        // nested looping of each grid within the i-th row that could contain j
        for (int k = 0; k < 9; k++) {
        result.append("G_");
        result.append(to_string(k+1));
        result.append("_");
        result.append(to_string(i+1));
        result.append("_");
        result.append(to_string(j+1));
        result.append(" ");
        }

      result.append("\n");
    }
  }

  return result;
}

string Formulas::outputFSBToGrid() {

  // string to store result in
  string result;

  // nested looping of j in i (denotes the subgrids; SB)
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {

      // nested looping of k (the number in the subgrid)
      for (int k = 0; k < 9; k++) {
        result.append("-SB_");
        result.append(to_string(i+1));
        result.append("_");
        result.append(to_string(j+1));
        result.append("_");
        result.append(to_string(k+1));
        result.append(" ");

        // nested looping of m in l (denotes individual grids within each subgrid)
        /* To maintain the standard in this code of outputting values as (+1) from their
        coded value, l and m and given triple the values of i and j respectively. The
        max values are adjusted similarly. */

        for (int l = i*3; l < i*3+3; l++) {       
          for (int m = j*3; m < j*3+3; m++) {
            result.append("G_");
            result.append(to_string(l+1));
            result.append("_");
            result.append(to_string(m+1));
            result.append("_");
            result.append(to_string(k+1));
            result.append(" ");

          }
        }

        result.append("\n");
      }
    }
  }

  return result;
}

string Formulas::outputFOneNumGrid() {

  // string to store result in
  string result;

  /* To output every clause proposing that each grid can only
  have one number, every individual grid will need a clause
  for every combination of two numbers ranging 1 to 9 without 
  repitition */

  // Initial nested loop to denote every grid in the board
  for (int i = 0; i < 9; i++) {
    for (int j = 0; j < 9; j++) {

      // looping of every combination without repition between numbers 1-9
      for (int k = 0; k < 9; k++) {
        for (int l = 0; l < 9; l ++) {

          // if statement prevents repition of numbers (k!=l in formula)
          if (k != l) {
            result.append("-G_");
            result.append(to_string(i+1));
            result.append("_");
            result.append(to_string(j+1));
            result.append("_");
            result.append(to_string(k+1));
            result.append(" ");

            result.append("-G_");
            result.append(to_string(i+1));
            result.append("_");
            result.append(to_string(j+1));
            result.append("_");
            result.append(to_string(l+1));
            result.append("\n");
          }
        }
      }
    }
  }

  return result;
}

#endif