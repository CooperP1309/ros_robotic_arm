#include <iostream>
#include <fstream>
#include <cstdlib>  
#include <string> 
#include <sstream>
#include "clause_outputs.h"
using namespace std;

int main() {
  
  ClauseOutput output;
  output.outputAll();

}

/*
By Cooper Peek 22093312
Use the following lines to compile and run this program:

  $ g++ -o clauses source.cpp
  $ ./clauses

Note: All three ".h" files must be in the same folder as
this "source.cpp" file when compiling.

Flow of class structure:
  
  formulas    sudoku
      |          |
      |          |
      ------------
           |
     clause_outputs
           |
      source/main     
*/