#ifndef CLAUSE_OUTPUTS_H
#define CLAUSE_OUTPUTS_H

#include <string>
#include "sudoku.h"
#include "formulas.h"
using namespace std;

class ClauseOutput {
private:
	string generateClauses();	// compiles the clauses of each formula into a single structure
	void outputTotals(string);	// gets the total amount of atoms and clauses

public: 
	void outputAll();		// outputs all of the required data by calling upon generative functions

};

string ClauseOutput::generateClauses() {
	
	// structure to hold our resulting clauses
	string result; 
	
	// objects of our hardcoded sudoku board and formulas
	Sudoku board;
	Formulas formula;


	result.append(formula.outputFMentions());
	result.append(formula.outputFRowToGrid());
	result.append(formula.outputFColToGrid());
	result.append(formula.outputFSBToGrid());
	result.append(formula.outputFOneNumGrid());
	result.append(board.outputSudokuGrids());

	// passing of resulting clauses to output function
	return result; 
}

void ClauseOutput::outputTotals(string clauses) {

	// data structs to store totals
  	int atomTotal = 0;
  	int clauseTotal = 0;

  	// string operation data structures
  	stringstream clausesString(clauses);
  	string buffer;

  	// iterate through every line, counting as you go
  	while (getline(clausesString, buffer)) {
    	clauseTotal++;
	  	}

	  // iterate through the results, counting spaces ()
	  for (int i = 0; i < clauses.size(); i++) {
	    
	    // case for a disjunction

	    /* no need to exclude the artifact spaces
	    at ends of clauses from count. These will acount
	    for the total amount of atoms per clause. */

	    if (clauses[i] == ' ') {
	      atomTotal++;
	    }
  	}

  	cout << atomTotal << " " << clauseTotal << "\n";

}

void ClauseOutput::outputAll() {

	string clauses;

	// generating and compiling of clauses
	clauses.append(generateClauses());

	// printing of totals and clauses
	outputTotals(clauses);
	cout << clauses;

}

#endif
