#ifndef SUDOKU_H
#define SUDOKU_H

#include <string>
using namespace std;

class Sudoku {
private:
	int** generateSudokuBoard();

public:
	string outputSudokuGrids();

};

int** Sudoku::generateSudokuBoard() {

  // initializing of our sudoku board
  int** sudokuBoard = new int*[9];
  for (int i = 0; i < 9; i++) {
    sudokuBoard[i] = new int[9];
  }

  // initialize the whole board to be empty
  for (int i = 0; i < 9; i++) {
    for (int j = 0; j < 9; j++) {
      sudokuBoard[i][j] = 0;
    }
  }

  /* NOTE TO SELF; This section is temporarily hard-coded.
  Future iterations will require this section to change.*/
  sudokuBoard[0][2] = 2;
  sudokuBoard[0][5] = 5;
  sudokuBoard[0][7] = 7;
  sudokuBoard[0][8] = 9;
  sudokuBoard[1][0] = 1;
  sudokuBoard[1][2] = 5;
  sudokuBoard[1][5] = 3;
  sudokuBoard[2][6] = 6;
  sudokuBoard[3][1] = 1;
  sudokuBoard[3][3] = 4;
  sudokuBoard[3][6] = 9;
  sudokuBoard[4][1] = 9;
  sudokuBoard[4][7] = 8;
  sudokuBoard[5][2] = 4;
  sudokuBoard[5][5] = 9;
  sudokuBoard[5][7] = 1;
  sudokuBoard[6][2] = 9;
  sudokuBoard[7][3] = 1;
  sudokuBoard[7][6] = 3;
  sudokuBoard[7][8] = 6; 
  sudokuBoard[8][0] = 6;
  sudokuBoard[8][1] = 8;
  sudokuBoard[8][3] = 3;
  sudokuBoard[8][6] = 4;

  return sudokuBoard;
}

string Sudoku::outputSudokuGrids() {

  // string to store resut in
  string result;

  int** board = new int*[9];
  board = generateSudokuBoard();

  /*
  // for testing the board data  
  for (int i = 0; i < 9; i++) {
    for (int j = 0; j < 9; j++) {
      cout << board[i][j] << " ";
    }
    cout << endl;
  }
  */

  // iterate through each grid
  for (int i = 0; i < 9; i++) {
    for (int j = 0; j < 9; j++) {
      
      // case for a grid containing a number
      if (board[i][j] != 0) {
        result.append("G_");
        result.append(to_string(i+1));
        result.append("_");
        result.append(to_string(j+1));
        result.append("_");
        result.append(to_string(board[i][j]));
        result.append("\n");
      }
    }
  }

  return result;
}

#endif