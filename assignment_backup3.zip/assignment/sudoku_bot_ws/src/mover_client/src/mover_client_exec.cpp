#include <ros/ros.h>
#include <mover_client/grid_num.h>
#include <mover_client/grid_num_vector.h>
#include <move_arm_joints/move_and_confirm.h>
#include <stdlib.h>
#include <iostream>
#include <vector>

mover_client::grid_num_vector grid_vector;
bool vector_received;

void grid_vector_received(const mover_client::grid_num_vector&);

int main(int argc, char **argv) {

	// initializing of node
	ros::init(argc, argv, "mover_client_node");
	ros::NodeHandle nh;
	ros::Subscriber sub = nh.subscribe("num_grids_sol/vector", 1000, &grid_vector_received);

	// implementing a client handler for each servo service
	ros::ServiceClient arm_shoulder_pan_client = nh.serviceClient<move_arm_joints::move_and_confirm>("move_arm_joints/arm_shoulder_pan_service");
	ros::ServiceClient arm_elbow_flex_client = nh.serviceClient<move_arm_joints::move_and_confirm>("move_arm_joints/arm_elbow_flex_service");
	ros::ServiceClient arm_wrist_flex_client = nh.serviceClient<move_arm_joints::move_and_confirm>("move_arm_joints/arm_wrist_flex_service");
	ros::ServiceClient arm_shoulder_lift_client = nh.serviceClient<move_arm_joints::move_and_confirm>("move_arm_joints/arm_shoulder_lift_service");
	ros::ServiceClient gripper_client = nh.serviceClient<move_arm_joints::move_and_confirm>("move_arm_joints/gripper_joint_service");

	// listening for a vector from the 'num_grids_sol/vector' topic
	ROS_INFO_STREAM("Listening for vectors...\n");	
	vector_received = false;	

	while (vector_received == false && ros::ok()) { 	// checking if the recieved flag is triggered yet
		ros::spinOnce();
	}

	ROS_INFO_STREAM("Sending request to service: 0.45..\n");

	move_arm_joints::move_and_confirm::Request req;
	move_arm_joints::move_and_confirm::Response resp;

	req.move = 0.45;

	if (!arm_shoulder_lift_client.call(req, resp)) {
		ROS_INFO_STREAM("Unable to contact service");
		return 0;
	}

	/*
	// gripper service call
	if (!gripper_client.call(req, resp)) {
		ROS_INFO_STREAM("Unable to contact service");
		return 0;
	}
	*/

	ROS_INFO_STREAM("Received resposne: " << resp.confirm << "\n");
}





/* ---------- functions ---------- */

void grid_vector_received(const mover_client::grid_num_vector& solution_vector) {

     ROS_INFO_STREAM("Received the following vector of grids:\n");        
    for( int i = 0; i < solution_vector.numbered_grids.size(); i++ )
    {
         ROS_INFO_STREAM("(" << solution_vector.numbered_grids[i].row <<"," 
         					 << solution_vector.numbered_grids[i].col <<"," 
         					 << solution_vector.numbered_grids[i].num <<")");

         if( i+1 != solution_vector.numbered_grids.size() )
	     	ROS_INFO_STREAM(", ");
    }
    ROS_INFO_STREAM("\n"); 

    grid_vector = solution_vector;	// assigning of our received vector to a global variable for use in the main function
    vector_received = true;	   	// setting of our flag - necessary for continuation of program   
}